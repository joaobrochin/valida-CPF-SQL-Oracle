DROP TABLE T_MC_SGV_OCORRENCIA_SAC;

drop FUNCTION fn_indice_satisfacao;

drop FUNCTION fn_VL_UNITARIO_LUCRO_PRODUTO;

drop FUNCTION fn_mc_gera_aliquota_media_icms_estado;

drop  VIEW VW_T_MC_SGV_OCORRENCIA_SAC;

drop PROCEDURE sp_update_T_MC_SGV_OCORRENCIA_SAC;